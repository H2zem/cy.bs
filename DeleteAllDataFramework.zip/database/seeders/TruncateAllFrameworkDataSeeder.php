<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class TruncateAllFrameworkDataSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0');

        try {

            $tables = [
                'control_audits_evidences',
                'control_audits_objectives',
                'framework_control_test_results',
                'framework_control_test_comments',
                'framework_control_test_audits',
                'audits_responsibles',
                'controls_control_objectives',
                'framework_control_tests',
                'framework_control_mappings',
                'framework_controls',
                'seeded_frameworks',
                'frameworks',
                'evidences',
            ];

            foreach ($tables as $table) {
                DB::table($table)->truncate();
            }

            Log::info('All framework related tables truncated successfully.');

        } catch (\Exception $e) {
            DB::statement('SET FOREIGN_KEY_CHECKS=1');
            throw $e;
        }

        DB::statement('SET FOREIGN_KEY_CHECKS=1');
    }
}
