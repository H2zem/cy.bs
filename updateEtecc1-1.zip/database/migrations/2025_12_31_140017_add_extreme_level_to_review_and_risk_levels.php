<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AddExtremeLevelToReviewAndRiskLevels extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('review_and_risk_levels', function (Blueprint $table) {
            $reviewLevelId = DB::table('review_levels')->insertGetId([
                'value' => 90,
                'name' => 'Extreme',
            ]);

            // Step 2: Insert new risk level "Extreme" referencing the review level
            DB::table('risk_levels')->insert([
                'value' => 25,
                'name' => 'Extreme',
                'color' => '#FF0000', // example color (red)
                'display_name' => 'Extreme',
                'review_level_id' => $reviewLevelId,
            ]);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('review_and_risk_levels', function (Blueprint $table) {
            // Delete the inserted risk level
            DB::table('risk_levels')
                ->where('value', 25)
                ->where('name', 'Extreme')
                ->delete();

            // Delete the inserted review level
            DB::table('review_levels')
                ->where('value', 90)
                ->where('name', 'Extreme')
                ->delete();
        });
    }
}
