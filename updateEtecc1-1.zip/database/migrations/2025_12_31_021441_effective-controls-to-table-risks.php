<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // غير 'reports' إلى اسم جدولك الصحيح
        Schema::table('risks', function (Blueprint $table) {
            $table->integer('effectiveness_of_current_controls')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('risks', function (Blueprint $table) {
            $table->dropColumn([
                'effectiveness_of_current_controls',
            ]);
        });
    }
};
