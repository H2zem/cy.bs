<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskConfigSource extends Model
{
    use HasFactory;
    protected $table = 'risk_config_sources';
    protected $fillable = [
        'name',
    ];

}
