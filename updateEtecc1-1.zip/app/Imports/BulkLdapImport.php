<?php

namespace App\Imports;

use App\Models\User;
use App\Models\Job;
use App\Models\Department;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Validator;

use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\Importable;

class BulkLdapImport implements ToCollection, WithHeadingRow, WithValidation
{
    use Importable;

    /**
     * =========================
     * HANDLE EXCEL ROWS
     * =========================
     */
    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {

            /*
            |--------------------------------------------------------------------------
            | 1. JOB (find or create)
            |--------------------------------------------------------------------------
            */
            $job = null;
            if (!empty($row['job'])) {
                $job = Job::firstOrCreate([
                    'name' => trim($row['job']),
                ]);
            }

            /*
            |--------------------------------------------------------------------------
            | 2. DEPARTMENTS HIERARCHY
            | division IS department (level 1)
            |--------------------------------------------------------------------------
            */
            $parentDepartment = null;

            $departmentLevels = [
                'division',
                'department',
                'department2',
                'department3',
                'department4',
            ];

            foreach ($departmentLevels as $column) {
                if (!empty($row[$column])) {
                    $parentDepartment = Department::firstOrCreate([
                        'name'      => trim($row[$column]),
                        'parent_id' => $parentDepartment?->id,
                    ]);
                }
            }

            /*
            |--------------------------------------------------------------------------
            | 3. USER
            |--------------------------------------------------------------------------
            */
            $defaultRoleId = 2;
            User::firstOrCreate(
                ['email' => trim($row['email'])],
                [
                    'name'          => trim($row['name']),
                    'username'      => strstr($row['email'], '@', true),
                    'password' => Hash::make('12345678'),
                    'job_id'        => $job?->id,
                    'department_id' => $parentDepartment?->id, // deepest department
                    'enabled'       => true,
                    'role_id'       => $defaultRoleId,
                    'type'       => 'ldap',
                ]
            );
        }
    }

    /**
     * =========================
     * BASIC VALIDATION
     * =========================
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'email'],
            'name'  => ['required'],

            'division'   => ['required'],   // root department
            'department' => ['required'],   // level 2

            'department2' => ['nullable'],
            'department3' => ['nullable'],
            'department4' => ['nullable'],

            'job' => ['nullable'],
        ];
    }

    /**
     * =========================
     * HIERARCHICAL VALIDATION
     * from the END to the ROOT
     * =========================
     */
    public function withValidator($validator)
    {
        $validator->after(function (Validator $validator) {

            foreach ($validator->getData() as $rowIndex => $row) {

                $division    = trim($row['division'] ?? '');
                $department  = trim($row['department'] ?? '');
                $department2 = trim($row['department2'] ?? '');
                $department3 = trim($row['department3'] ?? '');
                $department4 = trim($row['department4'] ?? '');

                if ($department2 && (!$department || !$division)) {
                    $validator->errors()->add(
                        "{$rowIndex}.department2",
                        'department2 requires department and division.'
                    );
                }

                if ($department3 && (!$department2 || !$department || !$division)) {
                    $validator->errors()->add(
                        "{$rowIndex}.department3",
                        'department3 requires department2, department and division.'
                    );
                }

                if ($department4 && (!$department3 || !$department2 || !$department || !$division)) {
                    $validator->errors()->add(
                        "{$rowIndex}.department4",
                        'department4 requires department3, department2, department and division.'
                    );
                }
            }
        });
    }
}
