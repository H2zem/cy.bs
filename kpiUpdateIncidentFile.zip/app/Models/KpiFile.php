<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KpiFile extends Model
{
    use HasFactory;

    protected $table = 'kpi_files';

    protected $fillable = [
        'user_id',
        'kpi_id',
        'initate_id',
        'display_name',
        'unique_name',
    ];

    /**
     * 🔗 User who uploaded the file
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * 🔗 KPI related to this file
     */
    public function kpi()
    {
        return $this->belongsTo(KPI::class, 'kpi_id');
    }

    public function initate()
    {
        return $this->belongsTo(KPIAssessment::class, 'initate_id');
    }
}
