<?php
namespace App\Http\Traits;
use App\Models\ItemsToTeam;
trait RiskTrait {

    /**
     * check and manage teams with item
     *
     * @return true
     */
    // public function SaveTestResultToRisk($resultId, $riskId) {
    //     // get current teams with specific item
        
        
    //     return true;
    // }
    
    
}