<?php

namespace App\Http\Controllers\admin\reporting;

use App\Http\Controllers\Controller;
use App\Http\Traits\RiskAssetTrait;
use App\Models\Risk;
use App\Models\RiskLevel;
use Illuminate\Http\Request;

class RiskCenterController extends Controller
{

    use RiskAssetTrait;

    public function index()
    {
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.risk_management.index'), 'name' => __('locale.Risk Management')],
            ['name' => __('locale.Risks and Controls')]
        ];
        $riskLevels = RiskLevel::all();

        $risks = Risk::with(['assets', 'mitigation.controls', 'exceptions'])->get();
         // Build the tree structure in PHP
        $treeData = [
            'name' => 'Risk Center',
            'type' => 'center',
            'children' => []
        ];
        foreach ($risks as $risk) {
            $score = optional($risk->riskScoring()->select('calculated_risk')->first())->calculated_risk;
            $riskNode = [
                'name' => $risk->subject ?? 'Risk',
                'id' => $risk->id ?? 'Id',
                'type' => 'risk',
                'details' => [
                    'id' => $risk->id,
                    'status' => $risk->status,
                    'subject' => $risk->subject,
                    'location' => $risk->locationsOfRisk->pluck('name')->implode(', '),
                    'team' => $risk->teamsForRisk->pluck('name')->implode(', '),
                    'inherent_risk' => $score,
                    'color_inherent' => riskScoringColor($score),
                ],
                'children' => $this->buildRecursiveChildren($risk)
            ];
            $treeData['children'][] = $riskNode;
        }
        return view('admin.content.reporting.risk-center', compact('breadcrumbs', 'riskLevels', 'treeData'));
    }

    // Recursive function to build children for any node (risk, asset, control, exception)
    private function buildRecursiveChildren($parent)
    {
        $children = [];
        // Assets
        if (isset($parent->assets) && $parent->assets->count() > 0) {
            $assetsChildren = [];
            foreach ($parent->assets as $asset) {
                $assetsChildren[] = [
                    'name' => $asset->name,
                    'type' => 'asset',
                    'details' => [
                        'id' => $asset->id,
                        'ip' => $asset->ip,
                        'name' => $asset->name,
                        'owner_email' => $asset->owner_email,
                        'category' => $asset->assetCategory->name ?? '',
                        'assetvalue' => $asset->assetValueLevel->name ?? '',
                        'location' => $asset->location->name ?? '',
                    ],
                    'children' => $this->buildRecursiveChildren($asset)
                ];
            }
            $children[] = [
                'name' => 'Assets',
                'type' => 'assets',
                'children' => $assetsChildren
            ];
        }

        // Threat Catalogs
        // Threat Catalogs (only for Risk model)
        if ($parent instanceof \App\Models\Risk && method_exists($parent, 'threatCatalogs') && $parent->threatCatalogs()->count() > 0) {
            $threatChildren = [];
            $threatCatalogs = $parent->threatCatalogs()->get();

            foreach ($threatCatalogs as  $threat) {
                $threatChildren[] = [
                    'name' => $threat->name ?? 'Threat',
                    'type' => 'threat',
                    'details' => [
                        'id' => $threat->id ?? null,
                        'name' => $threat->name ?? '',
                        'description' => $threat->description ?? '',
                    ],
                    'children' => []
                ];
            }
            $children[] = [
                'name' => 'Threat Catalogs',
                'type' => 'threatCatalogs',
                'children' => $threatChildren
            ];
        }

        // Controls from mitigation relation if available
        if (isset($parent->mitigation) && isset($parent->mitigation->controls) && $parent->mitigation->controls instanceof \Illuminate\Support\Collection && $parent->mitigation->controls->count() > 0) {
            $controlsChildren = [];
            foreach ($parent->mitigation->controls as $control) {
                $controlsChildren[] = [
                    'name' => $control->short_name ?? 'Control',
                    'type' => 'control',
                    'details' => [
                        'id' => $control->id ?? null,
                        'name' => $control->short_name ?? '',
                        'family' => $control->Family->name ?? '',
                        'description' => $control->description ?? '',
                        'control_number' => $control->control_number ?? '',
                        'control_type' => $control->type->name ?? '',
                        'control_class' => $control->class->name ?? '',
                        'control_phase' => $control->phase->name ?? '',
                        'control_priority' => $control->priority->name ?? '',
                        'control_maturity' => $control->maturity->name ?? '',
                        'owner' => $control->owner ? $control->owner->name : '',
                    ],
                    'children' => $this->buildRecursiveChildren($control)
                ];
            }
            $children[] = [
                'name' => 'Controls',
                'type' => 'controls',
                'children' => $controlsChildren
            ];
        } elseif (isset($parent->control) && $parent->control) {
            $control = $parent->control;
            $children[] = [
                'name' => 'Controls',
                'type' => 'controls',
                'children' => [[
                    'name' => $control->short_name ?? 'Control',
                    'type' => 'control',
                    'details' => [
                        'id' => $control->id ?? null,
                        'name' => $control->short_name ?? '',
                        'family' => $control->Family->name ?? '',
                        'description' => $control->description ?? '',
                        'control_number' => $control->control_number ?? '',
                        'control_type' => $control->type->name ?? '',
                        'control_class' => $control->class->name ?? '',
                        'control_phase' => $control->phase->name ?? '',
                        'control_priority' => $control->priority->name ?? '',
                        'control_maturity' => $control->maturity->name ?? '',
                        'owner' => $control->owner ? $control->owner->name : '',
                    ],
                    'children' => $this->buildRecursiveChildren($control)
                ]]
            ];
        }
        // Exceptions
        if (isset($parent->exceptions) && $parent->exceptions->count() > 0) {
            $exceptionsChildren = [];
            foreach ($parent->exceptions as $exception) {
                $exceptionsChildren[] = [
                    'name' => $exception->name,
                    'type' => 'exception',
                    'details' => [
                        'id' => $exception->id,
                        'title' => $exception->name,
                        'exception_creator' => $exception->user->name,
                        'request_duration' => $exception->request_duration,
                        'approval_date' => $exception->approval_date,
                    ],
                    'children' => $this->buildRecursiveChildren($exception)
                ];
            }
            $children[] = [
                'name' => 'Exceptions',
                'type' => 'exceptions',
                'children' => $exceptionsChildren
            ];
        }
        return $children;
    }
}

// Removed duplicate method and extra closing brace