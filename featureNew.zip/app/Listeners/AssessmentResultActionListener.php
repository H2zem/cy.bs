<?php

namespace App\Listeners;

use App\Events\AssessmentResultAction;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class AssessmentResultActionListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(AssessmentResultAction $event)
    {
        $action1 = Action::where('name', 'assessment_result')->first();
        $actionId1 = $action1['id'];
        $result = $event->result;
        $roles = [
            'Questionnaire-contact' => [$result->contact?->id] ?? null,
        ];
        $result->asset = $result->asset?->name;
        $result->contact = $result->contact?->name;
        $result->questionnaire = $result->questionnaire?->name;
        $link = ['link' => route('admin.questionnaire-results.index')];
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $result, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}