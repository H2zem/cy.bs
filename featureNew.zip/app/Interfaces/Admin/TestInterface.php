<?php


namespace App\Interfaces\Admin;

interface TestInterface
{
    public function testRepositoryTechineqe();
}
